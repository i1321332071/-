//地址信息js
var addresslist=[
  {
    username: '同',
    userphone: '18511633601',
    useraddress: '北京',
    addressname: '昌平区',
    sex: '先生'
  }, {
    username: '佟小强',
    userphone: '15561337396',
    useraddress: '广州',
    addressname: '白云区',
    sex: '女士'
  },
]
module.exports = {
  addresslist:addresslist
}